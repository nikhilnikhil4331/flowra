# Myflo images — JPG copies for sharing

Images inside this zip are JPG re-encodes (quality 88) of the originals,
which are kept at full quality in the repo under `public/images/`:

| JPG copy | Original (full quality) |
|----------|-------------------------|
| mascot-hero.jpg | public/images/mascot-hero.png |
| mascot-hello.jpg | public/images/mascot-hello.png |
| mascot-avatar.jpg | public/images/mascot-avatar.png |
| mascot-heart.jpg | public/images/mascot-heart.png |
| food-bowl.jpg | public/images/food-bowl.jpg |
| food-oats.jpg | public/images/food-oats.jpg |

Used by the app: mascot-hero = Splash screen; mascot-hello = Onboarding/Auth/Cycle History; mascot-avatar = circular avatars; mascot-heart = Home/Logs/Onboarding; food-bowl + food-oats = Nutrition cards.
